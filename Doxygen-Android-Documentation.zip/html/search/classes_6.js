var searchData=
[
  ['geoautocompleteadapter',['GeoAutoCompleteAdapter',['../classcom_1_1taller2_1_1llevame_1_1_views_1_1_geo_auto_complete_adapter.html',1,'com::taller2::llevame::Views']]],
  ['geosearchresult',['GeoSearchResult',['../classcom_1_1taller2_1_1llevame_1_1_models_1_1_geo_search_result.html',1,'com::taller2::llevame::Models']]]
];
