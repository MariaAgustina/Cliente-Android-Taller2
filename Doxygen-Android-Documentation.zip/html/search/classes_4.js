var searchData=
[
  ['estimatetriprequest',['EstimateTripRequest',['../classcom_1_1taller2_1_1llevame_1_1service_layer_model_1_1_estimate_trip_request.html',1,'com::taller2::llevame::serviceLayerModel']]]
];
