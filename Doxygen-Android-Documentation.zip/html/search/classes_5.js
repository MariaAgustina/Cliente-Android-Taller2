var searchData=
[
  ['facebookdata',['FacebookData',['../classcom_1_1taller2_1_1llevame_1_1_models_1_1_facebook_data.html',1,'com::taller2::llevame::Models']]],
  ['factoryactivities',['FactoryActivities',['../classcom_1_1taller2_1_1llevame_1_1_creational_1_1_factory_activities.html',1,'com::taller2::llevame::Creational']]]
];
