var searchData=
[
  ['isdriver',['isDriver',['../classcom_1_1taller2_1_1llevame_1_1_models_1_1_client.html#a610b6f1fd387778c77262313dd7970f6',1,'com::taller2::llevame::Models::Client']]]
];
