var searchData=
[
  ['httprequest',['HTTPRequest',['../classcom_1_1taller2_1_1llevame_1_1service_layer_model_1_1_h_t_t_p_request.html#af738215d3fa2cd32d15e89171c1d3605',1,'com::taller2::llevame::serviceLayerModel::HTTPRequest']]]
];
