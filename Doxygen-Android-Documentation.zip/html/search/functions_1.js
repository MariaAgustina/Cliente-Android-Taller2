var searchData=
[
  ['deleteprofile',['deleteProfile',['../classcom_1_1taller2_1_1llevame_1_1_profile_activity.html#a45165e0dce5fed92f4ec05b7612b9d21',1,'com.taller2.llevame.ProfileActivity.deleteProfile()'],['../classcom_1_1taller2_1_1llevame_1_1service_layer_model_1_1_client_request.html#a05859942dd3e15ef4655df5461d53ddb',1,'com.taller2.llevame.serviceLayerModel.ClientRequest.deleteProfile()']]],
  ['dologinwithfacebook',['doLoginWithFacebook',['../classcom_1_1taller2_1_1llevame_1_1_login_activity.html#a0c6c3dc38db696dd11ecd26f7826c932',1,'com::taller2::llevame::LoginActivity']]]
];
