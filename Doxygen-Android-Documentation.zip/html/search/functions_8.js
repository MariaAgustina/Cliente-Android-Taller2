var searchData=
[
  ['modifyprofile',['modifyProfile',['../classcom_1_1taller2_1_1llevame_1_1_profile_activity.html#a6588ce61d0f19549b4d68bf8801d6421',1,'com.taller2.llevame.ProfileActivity.modifyProfile()'],['../classcom_1_1taller2_1_1llevame_1_1service_layer_model_1_1_client_request.html#af65ce98a0047e2cb6fa4412cbf86178f',1,'com.taller2.llevame.serviceLayerModel.ClientRequest.modifyProfile()']]]
];
